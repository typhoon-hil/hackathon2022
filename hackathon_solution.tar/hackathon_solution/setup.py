from setuptools import setup

setup(
    name="hackathon_solution",
    install_requires="",
    entry_points={"uegos.plugin": ["solution = hackathon_solution"]},
    py_modules=["hackathon_solution"],
)
